#!/bin/sh

rm amiyabot-plugin-config-demo-*.zip
zip -q -r amiyabot-plugin-config-demo-1.5.zip *